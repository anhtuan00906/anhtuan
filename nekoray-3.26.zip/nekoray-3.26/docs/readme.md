# 技术文档

# Technical documentation

1. Build GUI: `Build_*.md`
2. Build Core: `Build_Core.md`
3. Hook.js usage: `HookJS.md`
