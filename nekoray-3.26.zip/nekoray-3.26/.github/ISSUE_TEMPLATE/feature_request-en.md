---
name: 'Feature Request'
about: 'Make suggestions for new features of the software'
title: ''
labels: ''
assignees: ''

---

## Description suggestions

## Necessity of recommendations
