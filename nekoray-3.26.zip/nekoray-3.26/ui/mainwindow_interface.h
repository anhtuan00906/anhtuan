#pragma once

#define MW_INTERFACE

#include "mainwindow.h"
