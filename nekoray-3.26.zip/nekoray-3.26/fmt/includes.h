#pragma once

#include "SocksHttpBean.hpp"
#include "ShadowSocksBean.hpp"
#include "ChainBean.hpp"
#include "VMessBean.hpp"
#include "TrojanVLESSBean.hpp"
#include "NaiveBean.hpp"
#include "QUICBean.hpp"
#include "CustomBean.hpp"
