SRC_ROOT="$PWD"
DEPLOYMENT="$SRC_ROOT/deployment"
BUILD="$SRC_ROOT/build"
version_standalone="nekoray-"$(cat nekoray_version.txt)
