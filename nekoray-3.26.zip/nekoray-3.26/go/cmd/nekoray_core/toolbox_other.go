//go:build !windows && !linux

package main

func ToolBox() {
}
