#pragma once

void Windows_SetCrashHandler();
