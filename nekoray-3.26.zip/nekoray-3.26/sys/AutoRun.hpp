#pragma once

void AutoRun_SetEnabled(bool enable);

bool AutoRun_IsEnabled();
