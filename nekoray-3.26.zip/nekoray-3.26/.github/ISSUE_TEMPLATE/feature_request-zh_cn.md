---
name: '功能请求'
about: '对软件的新功能提出建议。'
title: ''
labels: ''
assignees: ''

---

## 描述建议

## 建议的必要性
